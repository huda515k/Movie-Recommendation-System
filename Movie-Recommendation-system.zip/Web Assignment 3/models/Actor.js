// models/Actor.js
const mongoose = require('mongoose');

const actorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  biography: { type: String },
  awards: [{ type: String }], // List of awards won by the actor
  filmography: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Movie' 
  }], // List of movies the actor has been part of
  photos: [{ type: String }], // URLs of the actor's photos
  birthdate: { type: Date }
});

module.exports = mongoose.model('Actor', actorSchema);
