const mongoose = require('mongoose');

const discussionSchema = new mongoose.Schema({
  topic: { type: String, required: true },
  movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie' },
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
  posts: [
    {
      user: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
      content: String,
      timestamp: { type: Date, default: Date.now }
    }
  ]
}, { timestamps: true });

module.exports = mongoose.model('Discussion', discussionSchema);
