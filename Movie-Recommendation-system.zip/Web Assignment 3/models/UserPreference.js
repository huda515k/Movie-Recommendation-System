const userPreferenceExtension = {
    // Add these to your User schema or create a separate model
    notificationPreferences: {
      email: {
        newReleases: { type: Boolean, default: true },
        trailers: { type: Boolean, default: true },
        newsUpdates: { type: Boolean, default: true }
      },
      push: {
        newReleases: { type: Boolean, default: true },
        trailers: { type: Boolean, default: true },
        newsUpdates: { type: Boolean, default: true }
      }
    },
    releaseReminders: [{
      movie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie' },
      reminderDate: Date,
      notified: { type: Boolean, default: false }
    }]
  };