const mongoose = require('mongoose');

const customListSchema = new mongoose.Schema({
  name: { type: String, required: true },
  description: { type: String },
  movies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }],
  createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  followers: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }],
  isPublic: { type: Boolean, default: false }, // Whether the list is public or private
  createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model('CustomList', customListSchema);
