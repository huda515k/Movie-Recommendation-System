const mongoose = require('mongoose');

const newsArticleSchema = new mongoose.Schema({
  title: { type: String, required: true },
  content: { type: String, required: true },
  summary: { type: String },
  author: { type: String },
  publishDate: { type: Date, default: Date.now },
  category: {
    type: String,
    enum: ['movie', 'actor', 'industry', 'award', 'box-office'],
    required: true
  },
  tags: [String],
  relatedMovies: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Movie' }],
  relatedActors: [{ type: String }],
  imageUrl: String,
  source: String,
  sourceUrl: String
});

module.exports = mongoose.model('NewsArticle', newsArticleSchema);