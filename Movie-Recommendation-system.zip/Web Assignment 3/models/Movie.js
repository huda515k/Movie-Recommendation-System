const mongoose = require('mongoose');

const movieSchema = new mongoose.Schema({
  title: { type: String, required: true },
  genre: { type: [String], required: true }, // e.g., Drama, Action, Comedy
  director: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Director', // Reference to the Director Model
    required: true 
  },
  cast: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Actor' // Reference to the Actor Model
  }],
  releaseDate: { type: Date, required: true },
  runtime: { type: Number, required: true }, // In minutes
  synopsis: { type: String, required: true },
  averageRating: { type: Number, default: 0 }, // Calculated based on reviews
  coverPhotos: [{ type: String }], // URLs of cover photos
  trivia: { type: String }, // Trivia about the movie
  goofs: { type: String }, // Goofs or errors in the movie
  soundtrack: { type: String }, // Soundtrack details
  ageRating: { type: String }, // Age rating (e.g., PG-13, R)
  parentalGuidance: { type: String }, // Parental guidance information
  createdAt: { type: Date, default: Date.now }
});

const movieSchemaExtension = {
    // Add these to your existing Movie schema
    releaseDate: { type: Date },
    boxOffice: {
      openingWeekend: { type: Number },
      domestic: { type: Number },
      international: { type: Number },
      total: { type: Number }
    },
    awards: [{
      name: { type: String },
      category: { type: String },
      year: { type: Number },
      type: { type: String, enum: ['nomination', 'winner'] }
    }],
    trailers: [{
      url: { type: String },
      releaseDate: { type: Date },
      type: { type: String, enum: ['teaser', 'trailer', 'behind-the-scenes'] }
    }]
  };
  


module.exports = mongoose.model('Movie', movieSchema);
