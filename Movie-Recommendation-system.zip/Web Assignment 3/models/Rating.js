// models/Rating.js
const mongoose = require('mongoose');

const ratingSchema = new mongoose.Schema({
  movie: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Movie', 
    required: true 
  }, // Movie being rated
  user: { 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'User', 
    required: true 
  }, // User who rated
  rating: { 
    type: Number, 
    required: true, 
    min: 1, 
    max: 5 
  }, // Rating from 1 to 5
  review: { 
    type: String 
  }, // Optional review
  discussionCount: { 
    type: Number, 
    default: 0 
  }, // Track how many discussions this review has received
  createdAt: { 
    type: Date, 
    default: Date.now 
  }
});

module.exports = mongoose.model('Rating', ratingSchema);
