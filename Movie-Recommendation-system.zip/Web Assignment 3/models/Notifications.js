const mongoose = require('mongoose');
const notificationSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    type: {
      type: String,
      enum: ['release', 'trailer', 'news', 'award'],
      required: true
    },
    title: { type: String, required: true },
    message: { type: String, required: true },
    relatedMovie: { type: mongoose.Schema.Types.ObjectId, ref: 'Movie' },
    relatedNews: { type: mongoose.Schema.Types.ObjectId, ref: 'NewsArticle' },
    read: { type: Boolean, default: false },
    createdAt: { type: Date, default: Date.now }
  });
  
  module.exports = mongoose.model('Notification', notificationSchema);