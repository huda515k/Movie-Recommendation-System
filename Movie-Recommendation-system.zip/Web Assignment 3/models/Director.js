// models/Director.js
const mongoose = require('mongoose');

const directorSchema = new mongoose.Schema({
  name: { type: String, required: true },
  biography: { type: String },
  awards: [{ type: String }], // List of awards won by the director
  filmography: [{ 
    type: mongoose.Schema.Types.ObjectId, 
    ref: 'Movie' 
  }], // List of movies directed by the director
  photos: [{ type: String }], // URLs of the director's photos
  birthdate: { type: Date }
});

module.exports = mongoose.model('Director', directorSchema);
