const Watchlist = require('../models/Watchlist');
const Movie = require('../models/Movie');

// Add movie to user's watchlist
exports.addToWatchlist = async (req, res) => {
  const { movieId } = req.params;
  const userId = req.user.id;

  try {
    let watchlist = await Watchlist.findOne({ user: userId });
    if (!watchlist) {
      watchlist = new Watchlist({ user: userId, movies: [] });
    }

    if (!watchlist.movies.includes(movieId)) {
      watchlist.movies.push(movieId);
      await watchlist.save();
    }

    res.status(200).json({ message: 'Movie added to watchlist' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get user's watchlist
exports.getWatchlist = async (req, res) => {
  const userId = req.user.id;

  try {
    const watchlist = await Watchlist.findOne({ user: userId }).populate('movies', 'title');
    if (!watchlist) {
      return res.status(404).json({ message: 'No movies in watchlist' });
    }

    res.status(200).json(watchlist);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
