const Movie = require('../models/Movie');

exports.getUpcomingReleases = async (req, res) => {
  try {
    const upcomingMovies = await Movie.find({
      releaseDate: { 
        $gte: new Date() 
      }
    })
    .sort('releaseDate')
    .select('title releaseDate poster_path overview trailers');
    
    res.status(200).json(upcomingMovies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.setReleaseReminder = async (req, res) => {
  try {
    const user = await User.findById(req.user.userId);
    const { movieId } = req.params;
    
    // Check if reminder already exists
    const existingReminder = user.releaseReminders.find(
      reminder => reminder.movie.toString() === movieId
    );
    
    if (existingReminder) {
      return res.status(400).json({ message: 'Reminder already set for this movie' });
    }
    
    user.releaseReminders.push({
      movie: movieId,
      reminderDate: new Date() // You can customize this based on release date
    });
    
    await user.save();
    res.status(200).json({ message: 'Release reminder set successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};