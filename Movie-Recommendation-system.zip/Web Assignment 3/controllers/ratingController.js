// controllers/ratingController.js
const Rating = require('../models/Rating');
const Movie = require('../models/Movie');
const User = require('../models/User');

// Add a rating and review for a movie
exports.addRating = async (req, res) => {
  const { movieId, rating, review } = req.body;
  const userId = req.user.userId;

  try {
    // Check if the user has already rated the movie
    const existingRating = await Rating.findOne({ movie: movieId, user: userId });
    if (existingRating) {
      return res.status(400).json({ message: 'You have already rated this movie' });
    }

    // Create a new rating
    const newRating = new Rating({
      movie: movieId,
      user: userId,
      rating,
      review
    });

    await newRating.save();

    // Update the average rating for the movie
    const ratings = await Rating.find({ movie: movieId });
    const averageRating = ratings.reduce((acc, r) => acc + r.rating, 0) / ratings.length;

    await Movie.findByIdAndUpdate(movieId, { averageRating });

    res.status(201).json({ message: 'Rating and review added successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all ratings and reviews for a movie
exports.getRatingsForMovie = async (req, res) => {
  const { movieId } = req.params;

  try {
    // Get all ratings with user data
    const ratings = await Rating.find({ movie: movieId }).populate('user', 'username');
    if (!ratings) return res.status(404).json({ message: 'No ratings found for this movie' });

    // Get review highlights: top-rated and most-discussed reviews
    const topRatedReviews = ratings
      .filter(rating => rating.rating === 5) // Top-rated reviews
      .sort((a, b) => b.createdAt - a.createdAt); // Sort by date for freshest reviews

    const mostDiscussedReviews = ratings
      .sort((a, b) => b.discussionCount - a.discussionCount) // Sort by discussion count
      .slice(0, 5); // Get top 5 most-discussed reviews

    res.status(200).json({ 
      ratings,
      topRatedReviews,
      mostDiscussedReviews 
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update a rating and review
exports.updateRating = async (req, res) => {
  const { movieId, rating, review } = req.body;
  const userId = req.user.userId;

  try {
    const existingRating = await Rating.findOne({ movie: movieId, user: userId });
    if (!existingRating) {
      return res.status(404).json({ message: 'Rating not found' });
    }

    existingRating.rating = rating;
    existingRating.review = review;
    await existingRating.save();

    // Update the average rating for the movie
    const ratings = await Rating.find({ movie: movieId });
    const averageRating = ratings.reduce((acc, r) => acc + r.rating, 0) / ratings.length;

    await Movie.findByIdAndUpdate(movieId, { averageRating });

    res.status(200).json({ message: 'Rating and review updated successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a rating and review
exports.deleteRating = async (req, res) => {
  const { movieId } = req.params;
  const userId = req.user.userId;

  try {
    const rating = await Rating.findOneAndDelete({ movie: movieId, user: userId });
    if (!rating) {
      return res.status(404).json({ message: 'Rating not found' });
    }

    // Update the average rating for the movie
    const ratings = await Rating.find({ movie: movieId });
    const averageRating = ratings.length > 0
      ? ratings.reduce((acc, r) => acc + r.rating, 0) / ratings.length
      : 0;

    await Movie.findByIdAndUpdate(movieId, { averageRating });

    res.status(200).json({ message: 'Rating and review deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Increment discussion count (used when a user comments on a review)
exports.incrementDiscussionCount = async (req, res) => {
  const { ratingId } = req.params;

  try {
    const rating = await Rating.findById(ratingId);
    if (!rating) return res.status(404).json({ message: 'Rating not found' });

    rating.discussionCount += 1;
    await rating.save();

    res.status(200).json({ message: 'Discussion count updated' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};


// Get all ratings submitted by the logged-in user
// ratingController.js

// controllers/ratingController.js
exports.getUserRatings = async (req, res) => {
    try {
      const userId = req.user.id; // Getting user ID from JWT
      // Fetch all ratings from the user
      const ratings = await Rating.find({ user: userId }).populate('movie', 'title'); // Populate movie title
  
      if (!ratings.length) {
        return res.status(404).json({ message: 'No ratings found for this user' });
      }
  
      res.status(200).json(ratings);
    } catch (error) {
      console.error("Error fetching ratings:", error);
      res.status(500).json({ message: error.message });
    }
  };
  