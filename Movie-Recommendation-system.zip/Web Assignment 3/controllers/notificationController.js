const Notification = require('../models/Notifications');
const User = require('../models/User');


exports.getNotifications = async (req, res) => {
  try {
    console.log(req.user);
    const notifications = await Notification.find({ 
      user: req.user.userId,
      read: false 
    })
    .sort('-createdAt')
    .populate('relatedMovie');
    
    res.status(200).json(notifications);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.markNotificationRead = async (req, res) => {
  try {
    const notification = await Notification.findOneAndUpdate(
      { _id: req.params.notificationId, user: req.user.userId },
      { read: true },
      { new: true }
    );
    
    res.status(200).json(notification);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.updateNotificationPreferences = async (req, res) => {
  try {
    const user = await User.findByIdAndUpdate(
      req.user.userId,
      { 
        'notificationPreferences': req.body.preferences 
      },
      { new: true }
    );
    
    res.status(200).json(user.notificationPreferences);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

