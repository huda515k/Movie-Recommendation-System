const Movie = require('../models/Movie');
const Actor = require('../models/Actor');
const Director = require('../models/Director');
const Rating = require('../models/Rating'); // Assuming Rating model is used for rating-based recommendations
const User = require('../models/User');

// Create a new movie
exports.createMovie = async (req, res) => {
  const {
    title,
    genre,
    directorId,
    castIds,
    releaseDate,
    runtime,
    synopsis,
    coverPhotos,
    trivia,
    goofs,
    soundtrack,
    ageRating,
    parentalGuidance
  } = req.body;

  try {
    const director = await Director.findById(directorId);
    if (!director) return res.status(404).json({ message: 'Director not found' });

    const cast = await Actor.find({ '_id': { $in: castIds } });
    if (cast.length !== castIds.length) return res.status(404).json({ message: 'One or more cast members not found' });

    const newMovie = new Movie({
      title,
      genre,
      director: directorId,
      cast: castIds,
      releaseDate,
      runtime,
      synopsis,
      coverPhotos,
      trivia,
      goofs,
      soundtrack,
      ageRating,
      parentalGuidance
    });

    await newMovie.save();

    res.status(201).json({ message: 'Movie created successfully', newMovie });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all movies
exports.getMovies = async (req, res) => {
  try {
    const movies = await Movie.find()
      .populate('director', 'name')
      .populate('cast', 'name')
      .exec();

    res.status(200).json(movies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get a movie by ID (including all related data)
exports.getMovieById = async (req, res) => {
  const { movieId } = req.params;

  try {
    const movie = await Movie.findById(movieId)
      .populate('director', 'name biography awards photos')
      .populate('cast', 'name biography awards filmography photos')
      .exec();

    if (!movie) return res.status(404).json({ message: 'Movie not found' });

    res.status(200).json(movie);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Update a movie's details
exports.updateMovie = async (req, res) => {
  const { movieId } = req.params;
  const updates = req.body;

  try {
    const movie = await Movie.findById(movieId);
    if (!movie) return res.status(404).json({ message: 'Movie not found' });

    Object.assign(movie, updates);
    await movie.save();

    res.status(200).json({ message: 'Movie updated successfully', movie });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Delete a movie
exports.deleteMovie = async (req, res) => {
  const { movieId } = req.params;

  try {
    const movie = await Movie.findByIdAndDelete(movieId);
    if (!movie) return res.status(404).json({ message: 'Movie not found' });

    res.status(200).json({ message: 'Movie deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get similar movies based on genre or director
exports.getSimilarMovies = async (req, res) => {
  const { movieId } = req.params;

  try {
    const movie = await Movie.findById(movieId);
    if (!movie) return res.status(404).json({ message: 'Movie not found' });

    // Ensure movie.genre is an array
    const genreFilter = movie.genre && Array.isArray(movie.genre) ? { genre: { $in: movie.genre } } : {};
    const directorFilter = movie.director ? { director: movie.director } : {};

    // Combine filters for genre and director, limit results to 5
    const similarMovies = await Movie.find({
      $or: [
        genreFilter,
        directorFilter
      ]
    }).limit(5);

    res.status(200).json(similarMovies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get trending movies (based on ratings and reviews activity)
exports.getTrendingMovies = async (req, res) => {
  try {
    const trendingMovies = await Movie.aggregate([
      {
        $lookup: {
          from: 'ratings',
          localField: '_id',
          foreignField: 'movie',
          as: 'ratings'
        }
      },
      {
        $addFields: {
          ratingCount: { $size: '$ratings' }
        }
      },
      {
        $sort: { ratingCount: -1 }
      },
      {
        $limit: 5
      }
    ]);

    res.status(200).json(trendingMovies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get top-rated movies (based on average rating)
exports.getTopRatedMovies = async (req, res) => {
  try {
    const topRatedMovies = await Movie.aggregate([
      {
        $lookup: {
          from: 'ratings',
          localField: '_id',
          foreignField: 'movie',
          as: 'ratings'
        }
      },
      {
        $addFields: {
          avgRating: { $avg: '$ratings.rating' }
        }
      },
      {
        $sort: { avgRating: -1 }
      },
      {
        $limit: 5
      }
    ]);

    res.status(200).json(topRatedMovies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get personalized recommendations based on user preferences and ratings
// Get personalized recommendations based on user preferences and ratings
exports.getPersonalizedRecommendations = async (req, res) => {
    const userId = req.user.id; // The user ID should now be available from the token
  
    if (!userId) {
      return res.status(400).json({ message: 'User ID not provided in token' });
    }
  
    try {
      // Get the user's preferences (e.g., favorite genres)
      const user = await User.findById(userId).populate('wishlist');
      if (!user) {
        return res.status(404).json({ message: 'User not found' });
      }
  
      const userPreferences = user.preferences || []; // E.g., favorite genres
  
      // Get all movies that match the user's preferences (e.g., matching genres)
      const recommendedMovies = await Movie.find({
        genre: { $in: userPreferences }
      })
        .populate('director', 'name')
        .populate('cast', 'name')
        .exec();
  
      res.status(200).json(recommendedMovies);
    } catch (error) {
      console.error("Error fetching recommendations:", error);
      res.status(500).json({ message: error.message });
    }
  };
  



  // Search movies based on title, genre, director, or actors
  exports.searchMovies = async (req, res) => {
    const { query, searchBy = 'all' } = req.query;

    if (!query) {
        return res.status(400).json({ 
            success: false, 
            message: 'Search query is required' 
        });
    }

    try {
        let movies = [];
        const searchType = searchBy.toLowerCase();

        switch (searchType) {
            case 'director':
                // First find movies by populating director and then filtering
                movies = await Movie.find()
                    .populate({
                        path: 'director',
                        match: { name: { $regex: query, $options: 'i' } }
                    })
                    .populate('cast', 'name')
                    .select('title genre releaseDate rating director cast');
                
                // Filter out movies where director didn't match (will be null after populate with match)
                movies = movies.filter(movie => movie.director !== null);
                break;
            
            case 'actor':
                // First find movies by populating cast and then filtering
                movies = await Movie.find()
                    .populate({
                        path: 'cast',
                        match: { name: { $regex: query, $options: 'i' } }
                    })
                    .populate('director', 'name')
                    .select('title genre releaseDate rating director cast');
                
                // Filter out movies where no cast members matched
                movies = movies.filter(movie => movie.cast.length > 0);
                break;
            
            case 'genre':
                movies = await Movie.find({ 
                    genre: { $regex: query, $options: 'i' } 
                })
                .populate('director', 'name')
                .populate('cast', 'name')
                .select('title genre releaseDate rating director cast');
                break;
            
            case 'title':
                movies = await Movie.find({ 
                    title: { $regex: query, $options: 'i' } 
                })
                .populate('director', 'name')
                .populate('cast', 'name')
                .select('title genre releaseDate rating director cast');
                break;
            
            case 'all':
                // Search by title or genre
                const titleGenreMatches = await Movie.find({
                    $or: [
                        { title: { $regex: query, $options: 'i' } },
                        { genre: { $regex: query, $options: 'i' } }
                    ]
                })
                .populate('director', 'name')
                .populate('cast', 'name')
                .select('title genre releaseDate rating director cast');

                // Search by director name
                const directorMatches = await Movie.find()
                    .populate({
                        path: 'director',
                        match: { name: { $regex: query, $options: 'i' } }
                    })
                    .populate('cast', 'name')
                    .select('title genre releaseDate rating director cast');

                // Search by actor name
                const actorMatches = await Movie.find()
                    .populate({
                        path: 'cast',
                        match: { name: { $regex: query, $options: 'i' } }
                    })
                    .populate('director', 'name')
                    .select('title genre releaseDate rating director cast');

                // Combine all results, filter out null matches, and remove duplicates
                const allMovies = [
                    ...titleGenreMatches,
                    ...directorMatches.filter(movie => movie.director !== null),
                    ...actorMatches.filter(movie => movie.cast.length > 0)
                ];

                // Remove duplicates based on movie ID
                movies = Array.from(new Map(
                    allMovies.map(movie => [movie._id.toString(), movie])
                ).values());
                break;

            default:
                return res.status(400).json({
                    success: false,
                    message: 'Invalid searchBy parameter. Valid options are: director, actor, genre, title, or all'
                });
        }

        // Limit results to 20
        movies = movies.slice(0, 20);

        res.status(200).json({
            success: true,
            count: movies.length,
            data: movies
        });

    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ 
            success: false, 
            message: 'Error searching movies',
            error: error.message 
        });
    }
};

// Filter movies based on various criteria
exports.filterMovies = async (req, res) => {
  const {
    rating, // Rating filter (e.g., minimum rating)
    popularity, // Popularity filter (e.g., top-rated, trending)
    releaseYear, // Release year filter
    releaseDecade, // Release decade filter
    country, // Country of origin filter
    language, // Language filter
    keyword // Keyword filter (e.g., "based on a true story")
  } = req.query;

  const filterCriteria = {};

  if (rating) {
    filterCriteria.averageRating = { $gte: rating };
  }

  if (popularity) {
    // You can define a logic for popularity based on ratings or views
    if (popularity === 'top') {
      filterCriteria.averageRating = { $gte: 4 }; // Example: Only top-rated movies
    }
  }

  if (releaseYear) {
    filterCriteria.releaseDate = { $gte: new Date(`${releaseYear}-01-01`), $lt: new Date(`${releaseYear + 1}-01-01`) };
  }

  if (releaseDecade) {
    const startYear = Math.floor(releaseDecade / 10) * 10;
    filterCriteria.releaseDate = { $gte: new Date(`${startYear}-01-01`), $lt: new Date(`${startYear + 10}-01-01`) };
  }

  if (country) {
    filterCriteria.country = country; // Assuming `country` field exists in the schema
  }

  if (language) {
    filterCriteria.language = language; // Assuming `language` field exists in the schema
  }

  if (keyword) {
    filterCriteria.synopsis = { $regex: keyword, $options: 'i' }; // Searching in the synopsis for keywords
  }

  try {
    const filteredMovies = await Movie.find(filterCriteria)
      .populate('director', 'name')
      .populate('cast', 'name')
      .exec();

    res.status(200).json(filteredMovies);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};
