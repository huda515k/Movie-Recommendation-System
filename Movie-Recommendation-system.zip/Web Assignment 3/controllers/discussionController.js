const Discussion = require('../models/Discussion'); // Ensure correct path to the model

exports.createDiscussion = async (req, res) => {
    const { topic, movieId, userId } = req.body;
    try {
      const discussion = new Discussion({
        topic,
        movie: movieId,
        createdBy: userId,
        posts: []
      });
      await discussion.save();
      res.status(201).json(discussion);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  exports.addPostToDiscussion = async (req, res) => {
    const { discussionId, userId, content } = req.body;
    try {
      const discussion = await Discussion.findById(discussionId);
      discussion.posts.push({ user: userId, content });
      await discussion.save();
      res.status(200).json(discussion);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };


  exports.getDiscussionById = async (req, res) => {
    try {
      const { id } = req.params;
      const discussion = await Discussion.findById(id).populate('posts.user', 'username'); // Adjust if needed
      if (!discussion) {
        return res.status(404).json({ message: 'Discussion not found' });
      }
      res.status(200).json(discussion);
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
  };
  
  