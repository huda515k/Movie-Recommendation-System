const CustomList = require('../models/CustomList');
const Movie = require('../models/Movie');
const User = require('../models/User');

// Create a new custom list
exports.createCustomList = async (req, res) => {
    const { name, description, movieIds, isPublic } = req.body;
  
    if (!name || !Array.isArray(movieIds)) {
      return res.status(400).json({ message: 'Name and valid movieIds are required' });
    }
  
    if (!req.user || !req.user.userId) {  // Changed from req.user.id to req.user.userId
      return res.status(401).json({ message: 'User not authenticated' });
    }
  
    const userId = req.user.userId;  // Changed from req.user.id to req.user.userId
  
    try {
      const customList = new CustomList({
        name,
        description,
        movies: movieIds,
        createdBy: userId,
        isPublic,
      });
  
      await customList.save();
      res.status(201).json({ message: 'Custom list created successfully', customList });
    } catch (error) {
      res.status(500).json({ message: error.message });
    }
};

// Add movie to custom list
exports.addMovieToList = async (req, res) => {
  const { customListId, movieId } = req.params;

  try {
    const customList = await CustomList.findById(customListId);
    if (!customList) {
      return res.status(404).json({ message: 'Custom list not found' });
    }

    if (!customList.movies.includes(movieId)) {
      customList.movies.push(movieId);
      await customList.save();
    }

    res.status(200).json({ message: 'Movie added to list' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Remove movie from custom list
exports.removeMovieFromList = async (req, res) => {
  const { customListId, movieId } = req.params;

  try {
    const customList = await CustomList.findById(customListId);
    if (!customList) {
      return res.status(404).json({ message: 'Custom list not found' });
    }

    customList.movies.pull(movieId);
    await customList.save();

    res.status(200).json({ message: 'Movie removed from list' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// Get all custom lists
exports.getCustomLists = async (req, res) => {
    try {
        const customLists = await CustomList.find({
            $or: [
                { isPublic: true },
                { createdBy: req.user.id }
            ]
        }).populate('movies');
        res.status(200).json(customLists);
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};

// Follow a custom list
exports.followCustomList = async (req, res) => {
    const { customListId } = req.params;
    const userId = req.user.id;

    try {
        const user = await User.findById(userId);
        const customList = await CustomList.findById(customListId);

        if (!customList) {
            return res.status(404).json({ message: 'Custom list not found' });
        }

        if (!user.followedLists.includes(customListId)) {
            user.followedLists.push(customListId);
            await user.save();
        }

        res.status(200).json({ message: 'Custom list followed successfully' });
    } catch (error) {
        res.status(500).json({ message: error.message });
    }
};
