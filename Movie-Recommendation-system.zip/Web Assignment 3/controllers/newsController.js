const NewsArticle = require('../models/NewsArticle');

exports.getNews = async (req, res) => {
  try {
    const { category, page = 1, limit = 10 } = req.query;
    const query = category ? { category } : {};
    
    const news = await NewsArticle.find(query)
      .sort('-publishDate')
      .skip((page - 1) * limit)
      .limit(limit)
      .populate('relatedMovies');
    
    const total = await NewsArticle.countDocuments(query);
    
    res.status(200).json({
      news,
      total,
      currentPage: page,
      totalPages: Math.ceil(total / limit)
    });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.getNewsArticle = async (req, res) => {
  try {
    const article = await NewsArticle.findById(req.params.articleId)
      .populate('relatedMovies');
    
    if (!article) {
      return res.status(404).json({ message: 'Article not found' });
    }
    
    res.status(200).json(article);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};