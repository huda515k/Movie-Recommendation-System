// routes/ratingRoutes.js
const express = require('express');
const { addRating, getRatingsForMovie, updateRating, deleteRating, incrementDiscussionCount, getUserRatings } = require('../controllers/ratingController');  // Ensure the import for getUserRatings
const authMiddleware = require('../middlewares/authMiddleware');

const router = express.Router();

// Protected routes for ratings and reviews
router.post('/', authMiddleware, addRating); // Add a new rating and review
router.get('/:movieId', getRatingsForMovie); // Get all ratings for a movie, including review highlights
router.put('/', authMiddleware, updateRating); // Update a rating and review
router.delete('/:movieId', authMiddleware, deleteRating); // Delete a rating and review
router.patch('/discussion/:ratingId', authMiddleware, incrementDiscussionCount); // Increment discussion count for a review
// Define the route to get all ratings by the logged-in user
// routes/ratingRoutes.js
router.get('/ratings/my-ratings', authMiddleware, getUserRatings);

module.exports = router;
