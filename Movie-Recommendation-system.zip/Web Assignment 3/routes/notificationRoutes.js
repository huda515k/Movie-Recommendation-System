const express = require('express');
const router = express.Router();
const {
  getNotifications,
  markNotificationRead,
  updateNotificationPreferences
} = require('../controllers/notificationController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/notifications', authMiddleware, getNotifications);
router.put('/notifications/:notificationId/read', authMiddleware, markNotificationRead);
router.put('/notification-preferences', authMiddleware, updateNotificationPreferences);

module.exports = router;