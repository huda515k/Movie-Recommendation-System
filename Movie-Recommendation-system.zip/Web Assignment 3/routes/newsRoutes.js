const express = require('express');
const router = express.Router();
const { getNews, getNewsArticle } = require('../controllers/newsController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/news', getNews);
router.get('/news/:articleId', getNewsArticle);

module.exports = router;
