const express = require('express');
const router = express.Router();
const {
  getUpcomingReleases,
  setReleaseReminder
} = require('../controllers/releaseController');
const authMiddleware = require('../middlewares/authMiddleware');

router.get('/upcoming-releases', getUpcomingReleases);
router.post('/release-reminder/:movieId', authMiddleware, setReleaseReminder);

module.exports = router;