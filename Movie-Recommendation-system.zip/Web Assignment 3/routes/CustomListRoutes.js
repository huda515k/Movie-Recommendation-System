const express = require('express');
const { 
  createCustomList, 
  getCustomLists, 
  followCustomList, 
  addMovieToList, 
  removeMovieFromList 
} = require('../controllers/customListController');
const { addToWatchlist, getWatchlist } = require('../controllers/watchlistController');
const authMiddleware = require('../middlewares/authMiddleware');

const router = express.Router();

// Custom Lists Routes
router.post('/custom-list', authMiddleware, createCustomList); // Create custom list
router.get('/custom-lists', authMiddleware, getCustomLists); // Get all custom lists
router.post('/custom-list/follow/:customListId', authMiddleware, followCustomList); // Follow a custom list
router.post('/custom-list/:customListId/movie/:movieId', authMiddleware, addMovieToList); // Add movie to list
router.delete('/custom-list/:customListId/movie/:movieId', authMiddleware, removeMovieFromList); // Remove movie from list

module.exports = router;
