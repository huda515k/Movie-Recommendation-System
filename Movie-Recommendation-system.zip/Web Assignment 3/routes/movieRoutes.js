const express = require('express');
const {
  createMovie,
  getMovies,
  getMovieById,
  updateMovie,
  deleteMovie,
  getSimilarMovies,
  getPersonalizedRecommendations,
  getTrendingMovies,
  getTopRatedMovies,
  searchMovies, // New search route
  filterMovies // New filter route
} = require('../controllers/movieController');
const authMiddleware = require('../middlewares/authMiddleware');
const adminMiddleware = require('../middlewares/adminMiddleware');

const router = express.Router();

// Admin routes (Protected)
router.post('/', authMiddleware, adminMiddleware, createMovie); // Create a new movie

// Recommendation routes (Place specific routes above dynamic routes)
router.get('/trending', authMiddleware, getTrendingMovies); // Get trending movies based on recent activity
router.get('/top-rated', authMiddleware, getTopRatedMovies); // Get top-rated movies based on average ratings
router.get('/recommendations', authMiddleware, getPersonalizedRecommendations); // Get personalized recommendations based on user preferences
router.get('/similar/:movieId', authMiddleware, getSimilarMovies); // Get similar movies based on genre, director

// Search and Filter routes
router.get('/search', authMiddleware, searchMovies); // Search movies by title, genre, director, or actors
router.get('/filter', authMiddleware, filterMovies); // Filter movies based on various criteria

// General movie routes
router.get('/', authMiddleware, getMovies); // Get all movies
router.get('/:movieId', authMiddleware, getMovieById); // Get a specific movie by ID
router.put('/:movieId', authMiddleware, adminMiddleware, updateMovie); // Update movie details
router.delete('/:movieId', authMiddleware, adminMiddleware, deleteMovie); // Delete a movie

module.exports = router;
