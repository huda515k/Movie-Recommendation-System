require('dotenv').config(); // Load environment variables
const express = require('express');
const connectDB = require('./config/db'); // Ensure correct path to db.js

const userRoutes = require('./routes/userRoutes'); // Use consistent casing
const movieRoutes = require('./routes/movieRoutes'); // Import movie routes
const ratingRoutes = require('./routes/ratingRoutes'); // Import rating routes
const customListRoutes = require('./routes/CustomListRoutes'); // Fix import and casing
const newsRoutes = require('./routes/newsRoutes');
const notificationRoutes = require('./routes/notificationRoutes');
const releaseRoutes = require('./routes/releaseRoutes');
const discussionRoutes = require('./routes/discussionRoutes');

const app = express();

// Connect to MongoDB
connectDB();

// Middleware to parse JSON requests
app.use(express.json());

// Base route for health check (optional but recommended)
app.get('/', (req, res) => {
  res.send({ message: 'API is running...' });
});

// API Routes
app.use('/api/user', userRoutes);          // Authentication and user routes
app.use('/api/movies', movieRoutes);       // Movie routes
app.use('/api/ratings', ratingRoutes);     // Rating and review routes
app.use('/api/lists', customListRoutes);   // Custom list routes
app.use('/api', newsRoutes);
app.use('/api', notificationRoutes);
app.use('/api', releaseRoutes);
app.use('/api/discussion', discussionRoutes);


// Global error handler (optional)
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ message: 'Something went wrong!', error: err.message });
});

// Start the server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
